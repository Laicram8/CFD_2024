#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 22 09:34:16 2024

@author: sanchis
"""

# Development of a Python code to solve the two-dimensional
# Navier-Stokes equations on a rectangular domain.
# Import some relevant libraries
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.pylab as pylab
import matplotlib.animation
from utils import plt_rc_setup
from utils.plot import colorplate as cc 
import math
import scipy.sparse as sp
import scipy.linalg as scl
from scipy.sparse.linalg import splu
import argparse
from pathlib import Path
font_dict = {'fontsize': 25,'weight':'bold'}
fig_path  = "CA/"
Path(fig_path).mkdir(exist_ok=True)
parser = argparse.ArgumentParser()
parser.add_argument('-R',default=25,help="Choose from different model")
parser.add_argument('-Lx',default=1,type=int,help="Number of samples used for prediction")
parser.add_argument('-Ly',default=1,type=int,help="Number of samples used for prediction")
parser.add_argument('-Nx',default=30,type=int,help="Number of samples used for prediction")
parser.add_argument('-Ny',default=30,type=int,help="Number of samples used for prediction")
parser.add_argument('-t',default=0.001,type=float,help="Number of samples used for prediction")
args = parser.parse_args()

params = {'legend.fontsize': 12,
          'legend.loc':'best',
          'figure.figsize': (8,5),
          'lines.markerfacecolor':'none',
          'axes.labelsize': 12,
          'axes.titlesize': 12,
          'xtick.labelsize':12,
          'ytick.labelsize':12,
          'grid.alpha':0.6}
pylab.rcParams.update(params)

# Some useful functions:
def avg(A,axis=0):
    """
    Averaging function to go from cell centres (pressure nodes)
    to cell corners (velocity nodes) and vice versa.
    avg acts on index idim; default is idim=1.
    """
    if (axis==0):
        B = (A[1:,] + A[0:-1,])/2.
    elif (axis==1):
        B = (A[:,1:] + A[:,0:-1])/2.
    else:
        raise ValueError('Wrong value for axis')
    return B   

def DD(n,h):
    """
    One-dimensional finite-difference derivative matrix
    of size n times n for second derivative:
    h^2 * f’’(x_j) = -f(x_j-1) + 2*f(x_j) - f(x_j+1)

    Homogeneous Neumann boundary conditions on the boundaries
    are imposed, i.e.
    f(x_0) = f(x_1)
    if the wall lies between x_0 and x_1. This gives then
    h^2 * f’’(x_j) = + f(x_0) - 2*f(x_1) + f(x_2)
    = + f(x_1) - 2*f(x_1) + f(x_2)
    = f(x_1) + f(x_2)

    For n=5 and h=1 the following result is obtained:

    A =
    -1 1 0 0 0
    1 -2 1 0 0
    0 1 -2 1 0
    0 0 1 -2 1
    0 0 0 1 -1
    """
    A = np.eye(n)*-2 + np.eye(n, k=1) + np.eye(n, k=-1)
    A[0,0] = -1
    A[n-1,n-1] = -1
    A /= h**2
    
    return A

# Homemade version of Matlab tic and toc functions
def tic():
    import time
    global startTime_for_tictoc
    startTime_for_tictoc = time.time()

def toc():
    import time
    if 'startTime_for_tictoc' in globals():
        print("Elapsed time is " + str(time.time() - startTime_for_tictoc) + " seconds.")
    else:
        print("Toc: start time not set")

# Simulation parameters:
Pr = 0.71
Re = int(args.R)
Ri = 0.
dt = args.t
Tf = 100
Lx = args.Lx
Ly = args.Ly
Nx = args.Nx
Ny = args.Ny
namp = 0.
ig = 200
Pe = Pr*Re

# number of iteratins
casename = "RB"  #"RB"

Nit = int(Tf/dt) # we just choose total time, be sure is steady...
# edge coordinates
x = np.linspace(0, Lx, Nx+1)
y = np.linspace(0, Ly, Ny+1)
# grid spacing
hx = Lx/Nx
hy = Ly/Ny

# boundary conditions

# boundary conditions
Utop = 1.; Ubottom = 0.
Ttop = 1.; Tbottom = 0.

uN = Utop   *np.ones(Nx+1)
vN = np.zeros(Nx)

#uS = Ubottom*np.ones(Nx+1)
uS = np.zeros(Nx+1)
vS = np.zeros(Nx)

uW = np.zeros(Ny) 
vW = np.zeros(Ny+1)

uE = np.zeros(Ny) 
vE = np.zeros(Ny+1)

tN = Ttop   *np.ones(Nx)
#tS = Tbottom*np.ones(Nx)
tS = np.zeros(Nx)

U_evol = np.zeros(Nit)
V_evol = np.zeros(Nit)

# Compute system matrices for pressure 
# Laplace operator on cell centres: Fxx + Fyy
# First set homogeneous Neumann condition all around

Lp = np.kron(sp.eye(Ny).toarray(), DD(Nx,hx)) \
    + np.kron(DD(Ny,hy) , sp.eye(Nx).toarray())
# Set one Dirichlet value to fix pressure in that point
Lp[0,:] = 0.; Lp[0,0] = 1.
Lp_lu, Lp_piv = scl.lu_factor(Lp)
Lps = sp.csc_matrix(Lp)
Lps_lu = splu(Lps)

U = np.zeros((Nx-1,Ny))
V = np.zeros((Nx,Ny-1))

Xc,Yc = np.meshgrid(avg(x,0), avg(y,0))

T = np.zeros((Nx,Ny)) + (abs(Ttop-Tbottom))/Ly*Yc.T  

if (ig>0):
    metadata = dict(title='Lid-driven cavity', artist='SG2212')
    writer = matplotlib.animation.FFMpegWriter(fps=15, metadata=metadata)
    matplotlib.use("Agg")
    fig=plt.figure()
    writer.setup(fig,'cavity_temp_re%d.mp4'%Re,dpi=200)

# progress bar
print('[         |         |         |         |         ]')
tic()
for k in range(int(Nit)):
    # print("Iteration k=%i time=%.2e" % (k,k*dt))

    # include all boundary points for u and v (linear extrapolation
    # for ghost cells) into extended array (Ue,Ve)
    Ue = np.vstack((uW, U, uE))
    Ue = np.vstack((2*uS-Ue[:,0], Ue.T, 2*uN-Ue[:,-1])).T
    Ve = np.vstack((vS, V.T, vN)).T
    Ve = np.vstack((2*vW-Ve[0,:], Ve, 2*vE-Ve[-1,:]))

    # averaged (Ua,Va) of u and v on corners
    Ua = avg(Ue, 1)
    Va = avg(Ve, 0) 

    # Ue and Ve averaged on cell centers
    Ucc = avg(Ue, 0) # [Nx, Ny+2]
    Vcc = avg(Ve, 1) # [Nx+2, Ny]

    #  construct individual parts of nonlinear terms
    dUVdx = np.diff(Ua*Va, axis = 0)/hx # [Nx, Ny+1]
    dUVdy = np.diff(Ua*Va, axis = 1)/hy # [Nx+1, Ny]

    #Ub    = avg( Ue[:,1:-1],0);   
    #Vb    = ....
    
    dU2dx = np.diff(Ucc*Ucc, axis = 0)/hx # [Nx, Ny+1]
    dV2dy = np.diff(Vcc*Vcc, axis = 1)/hy # [Nx+1, Ny]

    # treat viscosity explicitly
    # viscous term at u
    viscu = np.diff(Ue[:,1:-1],axis=0,n=2)/hx**2 + np.diff(Ue[1:-1,:],axis=1,n=2)/hy**2 # [Nx-1,Ny]

    # viscous term at v
    viscv = np.diff(Ve[:,1:-1],axis=0,n=2)/hx**2 + np.diff(Ve[1:-1,:],axis=1,n=2)/hy**2 # [Nx, Ny-1]

    # Build convective and diffusive term
    conv_U = -dU2dx[:,1:-1] - dUVdy[1:-1,:]
    conv_V = -dUVdx[:,1:-1] - dV2dy[1:-1,:] # Convective terms
    diff_U = viscu/Re 
    diff_V = viscv/Re      # Diffusive terms

    # Temperature matrix with boundary conditions
    tW = T[0,:]
    tE = T[-1,:]
    Te_x = np.vstack((tW, T, tE))
    Te_y = np.vstack((2*tS-T[:,0], T.T, 2*tN-T[:,-1])).T

    # Temperature forcing term in velocity equation
    fy = Ri*avg(Te_y, 1)

    # compose final nonlinear term + explicit viscous terms
    U = U + dt*(conv_U + diff_U)
    V = V + dt*(conv_V + diff_V + fy[:,1:-1]) # with forcing term

    # pressure correction, Dirichlet P=0 at (1,1)
    rhs = 1/dt * (np.diff(np.vstack((uW,U,uE))      , axis=0)/hx + \
                  np.diff(np.vstack((vS, V.T, vN)).T, axis=1)/hy)
    rhs = np.reshape(rhs.T,(Nx*Ny,1))
    rhs[0] = 0

     # different ways of solving the pressure-Poisson equation:
    P = Lps_lu.solve(rhs)
    P = np.reshape(P.T,(Ny,Nx)).T

    # apply pressure correction
    U = U - dt*np.diff(P, axis = 0)/hx
    V = V - dt*np.diff(P, axis = 1)/hy

    # Temperature equation
    Hx = np.diff(avg(Te_x,0)*np.vstack((uW,U,uE))       , axis=0)/hx
    Hy = np.diff(avg(Te_y,1)*np.vstack((vS, V.T, vN)).T , axis=1)/hy
    
    #U_evol[k] = np.sqrt(Ua**2 + Va**2).T[6,6]

    diffusionT = (1/Pe) * (np.diff(Te_x,2,axis = 0)/(hx**2) + \
                           np.diff(Te_y,2,axis = 1)/(hy**2))
    H = -Hx - Hy + diffusionT
    T=T+dt*H

    ##recording history points
    if (k==1):
        print(U.shape,'Velocity array')
    U_evol[k] = U[15,15]
    V_evol[k] = V[15,15]

    # do postprocessing to file
    if (ig>0 and np.floor(k/ig)==k/ig):
        plt.clf()
        plt.contourf(avg(x),avg(y),T.T,levels=np.arange(0,1.05,0.05))
        plt.gca().set_aspect(1.)
        plt.colorbar()
        plt.title(f'Temperature at t={k*dt:.2f}')
        writer.grab_frame()

    # update progress bar
    if np.floor(51*k/Nit)>np.floor(51*(k-1)/Nit): 
        print('.',end='')

# finalise progress bar
print(' done. Iterations k=%i time=%.2f' % (k,k*dt))
toc()

if (ig>0):
    writer.finish()

# Visualisation of the flow field at the end time:

    
########### PLOTTING #############
"""
# Create subplots
fig, axes = plt.subplots(3, 1, figsize=(8, 10))

# Plot U_wit
axes[0].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,10],c=cc.blue, label='probe 1')
axes[0].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,25],c=cc.red, label='probe 2')
axes[0].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,50], label='probe 3')
axes[0].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,75], label='probe 4')
axes[0].set_xlabel('time')
axes[0].set_ylabel('U')

# Plot V_wit
axes[1].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,10],c=cc.blue, label='probe 1')
axes[1].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,25],c=cc.red, label='probe 2')
axes[1].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,50], label='probe 3')
axes[1].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,75], label='probe 4')
axes[1].set_xlabel('time')
axes[1].set_ylabel('V')

# Plot T_wit
axes[2].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,10],c=cc.blue, label='probe 1')
axes[2].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,25],c=cc.red, label='probe 2')
axes[2].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,50], label='probe 3')
axes[2].plot(np.linspace(0, Tf, int(Nit)), U_wit[0:,75], label='probe 4')
axes[2].set_xlabel('time')
axes[2].set_ylabel('T')
axes[2].legend(loc='lower right')

plt.savefig(fig_path + f'Conver.jpg',bbox_inches='tight',dpi=1000)
plt.tight_layout()
"""

Ua = np.vstack((uS,avg(np.vstack((uW,U,uE)),1).T,uN)).T
Va = np.vstack((vW,avg(np.vstack((vS,V.T,vN)).T,0),vE))

Ta = np.vstack((tW, T, tE))

print('coords',x[15],y[15])
plt.figure()
velocity_contour = plt.contourf(x, y, np.sqrt(Ua**2 + Va**2).T, 20, cmap='inferno')
plt.quiver(x, y, Ua.T, Va.T)
plt.gca().set_aspect(1.)
plt.colorbar(velocity_contour, cmap='inferno')
plt.title(f'Velocity at t={Tf:.2f}')
plt.savefig(fig_path + f'V.jpg',bbox_inches='tight',dpi=1000)
plt.show()

plt.figure()
plt.contourf(Xc,Yc,T.T,20, cmap='inferno')
#plt.quiver(x,y,Ua.T,Va.T)
plt.gca().set_aspect(1.)
plt.xlim((0,1))
plt.ylim((0,1))
plt.colorbar(plt.contourf(Xc,Yc,T.T,20, cmap='inferno'),cmap='inferno')
plt.title(f'Temperature at t={Tf:.2f}')
plt.tight_layout()
plt.savefig(fig_path + f'T.jpg',bbox_inches='tight',dpi=1000)
plt.show()

print('Divergence')
# compute divergence on cell centres
div = (np.diff( np.vstack( (uW,U, uE)),axis=0)/hx + \
        np.diff( np.vstack(( vS, V.T, vN)).T,axis=1)/hy)
plt.figure()
plt.pcolor(avg(x),avg(y),div.T,shading='nearest',cmap='inferno')
plt.gca().set_aspect(1.)
plt.colorbar(plt.pcolor(avg(x),avg(y),div.T,shading='nearest',cmap='inferno'),cmap='inferno')
plt.title(f'Divergence at t={Tf:.2f}')
plt.savefig(fig_path + f'D.jpg',bbox_inches='tight',dpi=1000)
plt.show()


#### PLOT SHOW GROWTH #########
plt.figure(figsize=(8, 6))
plt.plot(np.linspace(0, Tf, int(Nit)), U_evol, label='U', linestyle='-')  # You can adjust the linestyle as needed
plt.scatter(np.linspace(0, Tf, int(Nit)), V_evol, label='V', color='red')
# Scatter points on top of the line plot
plt.xlabel('time')
plt.ylabel(r"U")  # Use the column name for the y-axis label
plt.title('Velocity evolution')
plt.legend()
plt.grid(True)
plt.savefig(fig_path + f'RBC_veloc_evol_{Ra}.jpg',bbox_inches='tight',dpi=1000)
plt.show()

