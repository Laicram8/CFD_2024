
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 22 09:34:16 2024

@author: sanchis
"""

# Development of a Python code to solve the two-dimensional
# Navier-Stokes equations on a rectangular domain.
# Import some relevant libraries
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.pylab as pylab
import matplotlib.animation
import math
import scipy.sparse as sp
import scipy.linalg as scl
from scipy.sparse.linalg import splu
import argparse
from pathlib import Path
font_dict = {'fontsize': 25,'weight':'bold'}
fig_path  = "RB/un/"
Path(fig_path).mkdir(exist_ok=True)
"""
parser = argparse.ArgumentParser()
parser.add_argument('-R',default=25,help="Choose from different model")
parser.add_argument('-Lx',default=1,type=int,help="Number of samples used for prediction")
parser.add_argument('-Ly',default=1,type=int,help="Number of samples used for prediction")
parser.add_argument('-Nx',default=30,type=int,help="Number of samples used for prediction")
parser.add_argument('-Ny',default=30,type=int,help="Number of samples used for prediction")
parser.add_argument('-t',default=0.001,type=float,help="Number of samples used for prediction")
args = parser.parse_args()
"""

params = {'legend.fontsize': 12,
          'legend.loc':'best',
          'figure.figsize': (8,5),
          'lines.markerfacecolor':'none',
          'axes.labelsize': 12,
          'axes.titlesize': 12,
          'xtick.labelsize':12,
          'ytick.labelsize':12,
          'grid.alpha':0.6}
pylab.rcParams.update(params)

# Some useful functions:
def avg(A,axis=0):
    """
    Averaging function to go from cell centres (pressure nodes)
    to cell corners (velocity nodes) and vice versa.
    avg acts on index idim; default is idim=1.
    """
    if (axis==0):
        B = (A[1:,] + A[0:-1,])/2.
    elif (axis==1):
        B = (A[:,1:] + A[:,0:-1])/2.
    else:
        raise ValueError('Wrong value for axis')
    return B   

def DD(n,h):
    """
    One-dimensional finite-difference derivative matrix
    of size n times n for second derivative:
    h^2 * f’’(x_j) = -f(x_j-1) + 2*f(x_j) - f(x_j+1)

    Homogeneous Neumann boundary conditions on the boundaries
    are imposed, i.e.
    f(x_0) = f(x_1)
    if the wall lies between x_0 and x_1. This gives then
    h^2 * f’’(x_j) = + f(x_0) - 2*f(x_1) + f(x_2)
    = + f(x_1) - 2*f(x_1) + f(x_2)
    = f(x_1) + f(x_2)

    For n=5 and h=1 the following result is obtained:

    A =
    -1 1 0 0 0
    1 -2 1 0 0
    0 1 -2 1 0
    0 0 1 -2 1
    0 0 0 1 -1
    """
    A = np.eye(n)*-2 + np.eye(n, k=1) + np.eye(n, k=-1)
    A[0,0] = -1
    A[n-1,n-1] = -1
    A /= h**2
    
    return A

# Homemade version of Matlab tic and toc functions
def tic():
    import time
    global startTime_for_tictoc
    startTime_for_tictoc = time.time()

def toc():
    import time
    if 'startTime_for_tictoc' in globals():
        print("Elapsed time is " + str(time.time() - startTime_for_tictoc) + " seconds.")
    else:
        print("Toc: start time not set")

Pr = 0.71
Ra = 1715
Re = 1/Pr
dt = 0.0001
Tf = 10
Lx = 10.
Ly = 1.
Nx = 200
Ny = 20
namp = 0.1
ig = 200

# number of iteratins
Nit = int(Tf/dt)

# edge coordinates
x = np.linspace(0, Lx, Nx + 1) 
y = np.linspace(0, Ly, Ny + 1)

X,Y = np.meshgrid(x,y) # for later
Xc,Yc = np.meshgrid(avg(x,0), avg(y,0))

# grid spacing
hx = Lx/Nx
hy = Ly/Ny

# boundary conditions
Utop = 0.; Ubottom = 0.
Ttop = 0.; Tbottom = 1.

uN = Utop*np.ones(Nx+1)     ; vN = np.zeros(Nx)
uS = Ubottom*np.ones(Nx+1)  ; vS = np.zeros(Nx)
uW = np.zeros(Ny)           ; vW = np.zeros(Ny+1)
uE = np.zeros(Ny)           ; vE = np.zeros(Ny+1)

# Modified here:
tN = Ttop    * np.ones(Nx)
tS = Tbottom * np.ones(Nx) 

# Compute system matrices for pressure 
# Laplace operator on cell centres: Fxx + Fyy
# First set homogeneous Neumann condition all around
Lp = np.kron(sp.eye(Ny).toarray(), DD(Nx,hx)) \
    + np.kron(DD(Ny,hy) , sp.eye(Nx).toarray());
# Set one Dirichlet value to fix pressure in that point
Lp[0,:] = 0.; Lp[0,0] = 1.
Lp_lu, Lp_piv = scl.lu_factor(Lp)
Lps = sp.csc_matrix(Lp)
Lps_lu = splu(Lps)

U_evol = np.zeros(Nit)
V_evol = np.zeros(Nit)
U = np.zeros((Nx-1,Ny))
V = np.zeros((Nx,Ny-1))

T = np.zeros((Nx,Ny)) + (Ttop-Tbottom)/Ly*Yc.T + Tbottom + namp*(np.random.rand(Nx,Ny)-0.5)

tW = T[0,:]
tE = T[-1,:]
Ta = np.vstack((tW, T, tE))

plt.figure()
plt.contourf(Xc,Yc,T.T,20)
plt.gca().set_aspect(1.)
plt.xlim((0,Lx))
plt.ylim((0,Ly))
plt.colorbar(orientation = "horizontal")
plt.title('Temperature at t=0')
plt.tight_layout()
plt.savefig(fig_path + f'RBC_temp_t0_{Ra}.jpg',bbox_inches='tight',dpi=1000)

Ua = np.vstack((uS,avg(np.vstack((uW,U,uE)),1).T,uN)).T
Va = np.vstack((vW,avg(np.vstack((vS,V.T,vN)).T,0),vE))

plt.figure()
plt.contourf(x,y,np.sqrt(Ua**2+Va**2).T, 20)
plt.gca().set_aspect(1.)
plt.xlim((0,Lx))
plt.ylim((0,Ly))
plt.colorbar(orientation = "horizontal")
plt.title('Velocity at t=0')
plt.savefig(fig_path + f'RBC_veloc_t0_{Ra}.jpg',bbox_inches='tight',dpi=1000)

# progress bar
print('[         |         |         |         |         ]')
"""
if (ig>0):
    metadata = dict(title='RBC Ra=%d'%Ra, artist='SG2212')
    writer = matplotlib.animation.FFMpegWriter(fps=15, metadata=metadata)
    matplotlib.use("Agg")
    fig=plt.figure()
    writer.setup(fig,'RBC_video_ra%d.mp4'%Ra,dpi=200)
"""

tic()
for k in range(Nit):
    # print("Iteration k=%i time=%.2e" % (k,k*dt))

    # include all boundary points for u and v (linear extrapolation
    # for ghost cells) into extended array (Ue,Ve)
    Ue = np.vstack((uW, U, uE))
    Ue = np.vstack((2*uS-Ue[:,0], Ue.T, 2*uN-Ue[:,-1])).T # Instead of : 
                                                          # np.hstack( (2*uS-Ue[:,0,np.newaxis], 
                                                          # Ue, 2 2*uN-Ue[:,-1,np.newaxis]))
    Ve = np.vstack((vS, V.T, vN)).T
    Ve = np.vstack((2*vW-Ve[0,:], Ve, 2*vE-Ve[-1,:])) # [Nx+2, Ny+1]
    
    # averaged (Ua,Va) of u and v on corners
    Ua = avg(Ue, 1) # [Nx+1,Ny+1]
    Va = avg(Ve, 0) # [Nx+1,Ny+1]

    Ucc = avg(Ue, 0) # [Nx, Ny+2]
    Vcc = avg(Ve, 1) # [Nx+2, Ny]
    
    #  construct individual parts of nonlinear terms
    dUVdx = np.diff(Ua*Va, axis = 0)/hx # [Nx, Ny+1]
    dUVdy = np.diff(Ua*Va, axis = 1)/hy # [Nx+1, Ny]
    
    dU2dx = np.diff(Ucc*Ucc, axis = 0)/hx # [Nx, Ny+1]
    dV2dy = np.diff(Vcc*Vcc, axis = 1)/hy # [Nx+1, Ny]

    # treat viscosity explicitly
    #          diff([Nx+1,Ny],0) = [Nx-1,Ny]           diff([Nx-1,Ny+2],1) = [Nx-1,Ny]    
    viscu = np.diff(Ue[:,1:-1],axis=0,n=2)/hx**2 + \
            np.diff(Ue[1:-1,:],axis=1,n=2 )/hy**2 # [Nx-1,Ny]
    viscv = np.diff(Ve[:,1:-1],axis=0,n=2)/hx**2 + \
            np.diff(Ve[1:-1,:],axis=1,n=2 )/hy**2 # [Nx, Ny-1]

    # Build convective and diffusive term
    conv_U = -dU2dx[:,1:-1] - dUVdy[1:-1,:]
    conv_V = -dUVdx[:,1:-1] - dV2dy[1:-1,:] # Convective terms
    diff_U = viscu/Re 
    diff_V = viscv/Re      # Diffusive terms

    # Temperature matrix with boundary conditions
    tW = T[0,:]
    tE = T[-1,:]
    Te_x = np.vstack((tW, T, tE))
    Te_y = np.vstack((2*tS-T[:,0], T.T, 2*tN-T[:,-1])).T
    
    # Temperature forcing term in velocity equation
    fy = Ra*Pr*avg(Te_y, 1) # Different from task 1: Technically Ra*Pr = Ri
    
    # compose final nonlinear term + explicit viscous terms
    U = U + dt*(conv_U + diff_U)
    V = V + dt*(conv_V + diff_V + fy[:,1:-1]) # with forcing term

    # pressure correction, Dirichlet P=0 at (1,1)
    rhs = 1/dt * (np.diff(np.vstack((uW,U,uE))      , axis=0)/hx + \
                  np.diff(np.vstack((vS, V.T, vN)).T, axis=1)/hy)
    rhs = np.reshape(rhs.T,(Nx*Ny,1))
    rhs[0] = 0

    # different ways of solving the pressure-Poisson equation:
    P = Lps_lu.solve(rhs)
    P = np.reshape(P.T,(Ny,Nx)).T

    # apply pressure correction
    U = U - dt*np.diff(P, axis = 0)/hx
    V = V - dt*np.diff(P, axis = 1)/hy
    U_evol[k] = U[100,10]
    V_evol[k] = V[100,10]
    
    # Temperature equation
    Hx = np.diff(avg(Te_x,0)*np.vstack((uW,U,uE))      , axis=0)/hx
    Hy = np.diff(avg(Te_y,1)*np.vstack((vS, V.T, vN)).T, axis=1)/hy
    
    # This equation was modified compared to Task 1, with no Péclet number
    diffusionT = (np.diff(Te_x,2,axis = 0)/(hx**2) + \
                  np.diff(Te_y,2,axis = 1)/(hy**2))
    H = -Hx - Hy + diffusionT
    T=T+dt*H

    # do postprocessing to file
    """
    if (ig>0 and np.floor(k/ig)==k/ig):
        plt.clf()
        plt.contourf(avg(x),avg(y),T.T,levels=np.arange(0,1.05,0.05))
        plt.gca().set_aspect(1.)
        plt.colorbar(orientation = "horizontal")
        plt.title(f'Temperature at t={k*dt:.2f}')
        writer.grab_frame()
    """

    # update progress bar
    if np.floor(51*k/Nit)>np.floor(51*(k-1)/Nit): 
        print('.',end='')

# finalise progress bar
print(' done. Iterations k=%i time=%.2f' % (k,k*dt))
toc()

tW = T[0,:]
tE = T[-1,:]
Ta = np.vstack((tW, T, tE))

plt.figure()
plt.contourf(Xc,Yc,T.T,70,cmap='plasma')
plt.gca().set_aspect(1.)
plt.xlim((0,Lx))
plt.ylim((0,Ly))
plt.colorbar(orientation = "horizontal",cmap='plasma')
plt.title(f'Temperature at t={(k+1)*dt:.4f}')
plt.tight_layout()
plt.savefig(fig_path + f'RBC_temp_tfin_{Ra}.jpg',bbox_inches='tight',dpi=1000)
plt.show()

Ua = np.vstack((uS,avg(np.vstack((uW,U,uE)),1).T,uN)).T;
Va = np.vstack((vW,avg(np.vstack((vS,V.T,
                                  vN)).T,0),vE));

fig, ax = plt.subplots(3, 1)
contour_levels = 20

print('coords',x[100],y[10])
cbar0 = ax[0].contourf(x, y, np.sqrt(Ua**2 + Va**2).T, contour_levels,cmap='inferno')
ax[0].set_aspect(1.0)
fig.colorbar(cbar0, ax=ax[0], orientation="horizontal",cmap='inferno')
ax[0].set_title(f'Velocity at t={(k+1)*dt:.4f}')

cbar1 = ax[1].contourf(x, y, Ua.T, contour_levels,cmap='plasma')
ax[1].set_aspect(1.0)
fig.colorbar(cbar1, ax=ax[1], orientation="horizontal",cmap='plasma')
ax[1].set_title(f'Horizontal velocity at t={(k+1)*dt:.4f}')

cbar2 = ax[2].contourf(x, y, Va.T, contour_levels,cmap='magma')
ax[2].set_aspect(1.0)
fig.colorbar(cbar2, ax=ax[2], orientation="horizontal",cmap='magma')
ax[2].set_title(f'Vertical velocity at t={(k+1)*dt:.4f}')

fig.tight_layout()
plt.savefig(fig_path + f'RBC_veloc_tfin_{Ra}.jpg',bbox_inches='tight',dpi=1000)

plt.show()


#### PLOT SHOW GROWTH #########
plt.figure(figsize=(8, 6))
plt.plot(np.linspace(0, Tf, int(Nit)), U_evol, label='U', linestyle='-')  # You can adjust the linestyle as needed
plt.scatter(np.linspace(0, Tf, int(Nit)), V_evol, label='V', color='red')
# Scatter points on top of the line plot
plt.xlabel('time')
plt.ylabel(r"U")  # Use the column name for the y-axis label
plt.title('Velocity evolution')
plt.legend()
plt.grid(True)
plt.savefig(fig_path + f'RBC_veloc_evol_{Ra}.jpg',bbox_inches='tight',dpi=1000)
plt.show()

